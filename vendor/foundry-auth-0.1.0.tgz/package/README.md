# @foundry/auth

Relying-party SDK for verifying [AuthPak](https://authpak.foundry-ns.com) sessions in any `*.foundry-ns.com` Cloudflare app.

## Server (Hono)
```ts
import { foundryAuth, type FoundryAuthVariables } from "@foundry/auth";
import { Hono } from "hono";

const app = new Hono<{ Variables: FoundryAuthVariables }>();
app.use("/api/*", foundryAuth()); // defaults to authpak.foundry-ns.com / aud "foundry-ns"
app.get("/api/me", (c) => c.json({ user: c.get("user"), orgId: c.get("orgId"), role: c.get("role") }));
```
Unauthenticated browser navigations 302 to the AuthPak login (`?redirect_uri=` back); XHR/API requests get `401 {error:{code:"unauthenticated"}}`. Override with `onUnauthenticated`.

## Server (framework-agnostic)
```ts
import { verifyFoundrySession } from "@foundry/auth";
const claims = await verifyFoundrySession(request); // FoundryClaims | null
```
Never throws; returns `null` for any invalid/missing token. Reads the `fnd_session` cookie or `Authorization: Bearer`.

## Browser
```ts
import { createFoundryClient } from "@foundry/auth/client";
const auth = createFoundryClient();
const session = await auth.getSession();           // GET /api/session
const res = await auth.fetchWithAuth("/api/data"); // refresh once on 401, else bounce to login
```

## Options
`jwksUrl`, `issuer`, `audience`, `cookieName`, `loginUrl` — all default to the AuthPak production values and are overridable.
